#include <iostream>
using namespace std;
int main() {
   // Knock Knock
   cout << "Knock Knock\n"
   << "Who's There\n"
   << "Who\n" << "Who who?\n" 
   << "Owl \"Something about an Owl (i forgot)\"\n";
   return 0;
}
